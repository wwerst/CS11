#include "regex.hh"


Range find(vector<RegexOperator *> regex, const string &s);
bool match(vector<RegexOperator *> regex, const string &s);

